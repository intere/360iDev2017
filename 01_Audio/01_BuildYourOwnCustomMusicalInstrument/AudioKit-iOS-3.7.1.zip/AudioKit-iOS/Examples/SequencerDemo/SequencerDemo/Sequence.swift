//
//  Sequence.swift
//  SequencerDemo
//
//  Created by Kanstantsin Linou on 6/30/16.
//  Copyright © 2016 AudioKit. All rights reserved.
//

enum Sequence: Int {
    case melody = 0, bassDrum, snareDrum, snareGhost
}
