//
//  AppDelegate.h
//  HelloObjectiveC
//
//  Created by Aurelius Prochazka on 1/27/16.
//  Copyright © 2016 AudioKit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

