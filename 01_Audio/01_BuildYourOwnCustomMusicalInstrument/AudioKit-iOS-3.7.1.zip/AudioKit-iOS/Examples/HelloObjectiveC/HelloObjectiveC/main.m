//
//  main.m
//  HelloObjectiveC
//
//  Created by Aurelius Prochazka on 1/27/16.
//  Copyright © 2016 AudioKit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
