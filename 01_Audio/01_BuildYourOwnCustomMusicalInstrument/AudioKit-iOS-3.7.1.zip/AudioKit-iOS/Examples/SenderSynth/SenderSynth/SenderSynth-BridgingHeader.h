//
//  SenderSynth-BridgingHeader.h
//  SenderSynth
//
//  Created by Aurelius Prochazka on 10/7/16.
//  Copyright © 2016 AudioKit. All rights reserved.
//

#ifndef SenderSynth_BridgingHeader_h
#define SenderSynth_BridgingHeader_h

#import "Audiobus.h"

#endif /* SenderSynth_BridgingHeader_h */
