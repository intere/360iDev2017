//
//  AnalogSynthX-BridgingHeader.h
//  AnalogSynthX
//
//  Created by Aurelius Prochazka on 10/7/16.
//  Copyright © 2016 AudioKit. All rights reserved.
//

#ifndef AnalogSynthX_BridgingHeader_h
#define AnalogSynthX_BridgingHeader_h

#import "Audiobus.h"

#endif /* AnalogSynthX_BridgingHeader_h */
