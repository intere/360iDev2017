//
//  FilterEffects-BridgingHeader.h
//  FilterEffects
//
//  Created by Aurelius Prochazka on 10/8/16.
//  Copyright © 2016 AudioKit. All rights reserved.
//

#ifndef FilterEffects_BridgingHeader_h
#define FilterEffects_BridgingHeader_h

#import "Audiobus.h"

#endif /* FilterEffects_BridgingHeader_h */
