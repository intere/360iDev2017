//
//  AudioKitPlaygrounds.h
//  AudioKitPlaygrounds
//
//  Created by Aurelius Prochazka on 4/5/17.
//  Copyright © 2017 AudioKit. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for AudioKitPlaygrounds.
FOUNDATION_EXPORT double AudioKitPlaygroundsVersionNumber;

//! Project version string for AudioKitPlaygrounds.
FOUNDATION_EXPORT const unsigned char AudioKitPlaygroundsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AudioKitPlaygrounds/PublicHeader.h>


