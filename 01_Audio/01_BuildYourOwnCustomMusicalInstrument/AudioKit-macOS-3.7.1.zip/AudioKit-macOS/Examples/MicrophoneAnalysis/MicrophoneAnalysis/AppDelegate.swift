//
//  AppDelegate.swift
//  MicrophoneAnalysis
//
//  Created by Kanstantsin Linou on 6/14/16.
//  Copyright © 2016 AudioKit. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }

}
