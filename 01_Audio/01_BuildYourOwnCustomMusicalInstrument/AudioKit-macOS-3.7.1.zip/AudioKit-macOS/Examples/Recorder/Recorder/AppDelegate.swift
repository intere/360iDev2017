//
//  AppDelegate.swift
//  Recorder
//
//  Created by Aurelius Prochazka on 2/4/17.
//  Copyright © 2017 Aurelius Prochazka. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }

}
