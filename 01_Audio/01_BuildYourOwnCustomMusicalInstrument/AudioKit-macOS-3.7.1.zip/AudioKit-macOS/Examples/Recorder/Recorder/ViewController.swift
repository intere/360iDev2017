//
//  ViewController.swift
//  Recorder
//
//  Created by Aurelius Prochazka on 2/4/17.
//  Copyright © 2017 Aurelius Prochazka. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }

    @IBAction func record(_ sender: Any) {
    }
    @IBAction func play(_ sender: Any) {
    }
    @IBAction func stop(_ sender: Any) {
    }
    @IBAction func reset(_ sender: Any) {
    }

}
